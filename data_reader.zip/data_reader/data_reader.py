import os
import helpers as aux

#class to read the files and include the info for easy access:
class DataFile:
    filename = ""
    directory = ""
    value = ""
    unit = ""
    datetime = ""
    extension = ""
    def __init__(self, fname, folder = "", pattern = "%Y-%m-%d-%H.%M.%S"): #https://docs.python.org/2/library/re.html
        if folder == "": #fname == full folder location
            self.directory, self.filename = os.path.split(fname)
        else:
            self.filename = fname
            self.directory = folder
        #pattern defines the pattern for the date time, the rest is fixed such as [decimal-numbers][unit(a set of non blank characters)]_[DATETIME].[EXTENSION]
        #You could add more advanced patterns in the helpers.py
        self.value, self.unit, self.datetime, self.extension = aux.basic_read_string(fname, pattern)

''' class DataFiles:
    #TODO: a lot
    def __init__(self, f)
     '''
if (__name__ == '__main__'):
    path = r"F:\Onedrive\Academic Files\LKB\rabi_fitting\data\0800ma_2018-12-19-10.44.36.csv"
    file = DataFile(path)
    print(file.directory)
    print(file.filename)
    print(file.extension)
    print(file.value)
    print(file.unit)
    print(file.datetime)